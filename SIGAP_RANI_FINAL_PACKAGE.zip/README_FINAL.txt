SIGAP RANI FINAL

Project berhasil diekstrak.

Langkah upload ke GitHub:
1. Buka repository GitHub.
2. Klik Add file > Upload files.
3. Drag seluruh isi folder ini (bukan folder pembungkusnya).
4. Commit changes.
5. Tunggu GitHub Pages 1-2 menit.

Catatan:
File proyek berhasil diekstrak agar dapat diedit lebih lanjut.
